sueldo=int(input("ingresa tu sueldo:"))
antiguedad=int(input("ingresa tu tiempo de antiguedad:"))

veinte=sueldo*0.20
cinco=sueldo*0.05

if sueldo <500 and antiguedad >= 10:
    print(f"tienes un aumento del 20%, su sueldo a pagar es: {veinte}")
elif sueldo <500 and antiguedad < 10:
    print(f"tienes un aumento del 5%, su sueldo a pagar es: {cinco}")
elif sueldo>=500:
    print(f"su sueldo es:{sueldo}")
