
numero1=int(input("ingresa el primer numero: "))
numero2=int(input("ingresa el segundo numero: "))
suma=numero1+numero2
diferencia=numero1-numero2
producto=numero2*numero1
division=numero1/numero2
if numero1 > numero2:
    print(f"la suma de los numeros es: {suma}")
    print(f"diferencia de los dos numeros es: {diferencia}")
else:
    print(f"el producto de los dos numeros es: {producto}")
    print(f"la division de los dos numeros es: {division}")
