numero=int(input("ingresa un numero de 1-99: "))
if numero <10:
    print(f"tu numero {numero}  es de un digito")
else:
    print(f"tu numero {numero} es de dos digitos")