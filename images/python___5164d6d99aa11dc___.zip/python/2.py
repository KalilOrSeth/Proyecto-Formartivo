frutas = {'mora': 2800, 'mango': 2000, 'maracuya': 5000, 'Naranja': 4000}

print(f"estas son las frutas disponibles  {frutas}")
fruta = input('¿que fruta quieres? ')
kg = float(input('¿cuantos kilos? '))

if fruta in frutas:
    precio= frutas[fruta] * kg
    print(f"{kg} kilos de {fruta} valen {precio:.3f} ")
else:
    print(f" la fruta {fruta} no esta disponible")
