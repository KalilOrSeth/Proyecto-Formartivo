clientes = {}
opcion = ""
while opcion != "terminar":
    if opcion == "añadir":
        cedula = input("introduce el numero de cedula del cliente: ")
        nombre = input("introduce el nombre del cliente: ")
        direccion = input("introduce la direccion del cliente: ")
        telefono = input("introduce el telefono del cliente: ")
        email = input("introduce el correo del cliente: ")
        preferente = input("¿es un cliente preferente (si/no) ? ")
        cliente = {"nombre":nombre, "direccion":direccion, "telefono":telefono, "email":email, "preferente":preferente=="si"}
        clientes[cedula] = cliente
    if opcion == "eliminar":
        cedula = input("Introduce la cedula del cliente: ")
        if cedula in clientes:
            del clientes[cedula]
        else:
            print("No existe el cliente con la cedula", cedula)
    if opcion == "mostrar":
        cedula = input("Introduce la cedula del cliente: ")
        if cedula in clientes:
            print("cedula:", cedula)
            for contra, valor in clientes[cedula].items():
                print(contra.title() + ":", valor)
        else:
            print("No existe el cliente con la cedula", cedula)
    if opcion == "listar clientes":
        print("Lista de clientes")
        for contra, valor in clientes.items():
            print(contra, valor["nombre"])
    if opcion == "listar clientes preferentes":
        print("Lista de clientes preferentes")
        for contra, valor in clientes.items():
            if valor["preferente"]:
                print(contra, valor["nombre"])
    opcion = input(" Añadir cliente(añadir) Eliminar cliente(eliminar) Mostrar cliente(mostrar) Listar clientes(listar clientes) Listar clientes preferentes(listar clientes preferentes) Terminar (terminar) Elige una opción:")