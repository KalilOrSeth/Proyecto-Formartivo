facturas = {}
cobrar= 0
pendiente = 0
camilo = ''
while camilo != 'terminar':
    if camilo == 'añadir':
        contrasena = input('introduce el numero de la factura: ')
        costo = float(input('introduce el coste de la factura: '))
        facturas[contrasena] = costo
        pendiente += costo
    if camilo == 'pagar':
        contrasena = input('introduce el numero de la factura a pagar: ')
        costo = facturas.pop(contrasena, 0)
        cobrar += costo
        pendiente -= costo
    print('Recaudado:', cobrar)
    print('Pendiente de cobro: ', pendiente)
    camilo = input('¿Quieres añadir una nueva factura (añadir), pagarla (pagar) o terminar (terminar)? ')
