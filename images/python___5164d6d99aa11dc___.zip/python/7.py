preguntas=int(input("ingrese la cantidad  de preguntas :"))
correctas=int(input("ingrese la cantidad  de preguntas correctas:"))
porcentaje=correctas * 100 / preguntas
if porcentaje>=90:
    print("nivel maximo")
else:
    if porcentaje>=75:
        print("nivel medio")
    else:
        if porcentaje>=50:
            print("nivel regular")
        else:
            print("fuera de nivel")