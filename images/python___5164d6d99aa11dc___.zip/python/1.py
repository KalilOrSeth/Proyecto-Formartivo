import random

intentos=0
print(input("cual es tu nombre: "))

numero=random.randint(1,30)
print("adivina el numero de 1-30")
while intentos<10:
    print("hora de adivinar")
    adivina =input()
    adivina=int(adivina)

    intentos=intentos+1

    if adivina <numero:
        print("frio")
    if adivina >numero:
        print("caliente")
    if adivina ==numero:
        break
if adivina ==numero:
    intentos = str(intentos)
    print("Has adivinado el numero "  "tu numero de intentos fueron:" + intentos )
if adivina !=numero:
    numero=str(numero)
    print("perdiste  "  "el numero que pensaba era :" + numero)
