precio=int(input("ingrese el precio del producto: "))
cantidad=int(input("ingrese la cantidad de productos a llevar: "))
Total=precio*cantidad
print(" debe pagar: ")
print(Total)