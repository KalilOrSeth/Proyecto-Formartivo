#Realizar un programa que lea cuatro valores numéricos e informar su suma y promedio

numero1=int(input("ingresa el primer numero: "))
numero2=int(input("ingresa el segundo numero: "))
numero3=int(input("ingresa el tercer numero: "))
numero4=int(input("ingresa el cuarto numero: "))
suma=numero1+numero2+numero3+numero4
promedio=suma/4

print(f"la suma de los 4 numeros es:  {suma}")
print(f"el promedio de los 4 numeros es: {promedio} " )
